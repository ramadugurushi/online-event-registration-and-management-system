# EventHub – Frontend

A responsive HTML, CSS and vanilla JavaScript frontend for **Problem Statement 27: Online Event Registration and Management System**.

## Run the frontend
1. Extract the ZIP file.
2. Open `index.html` in a browser, or use VS Code Live Server.
3. The page initially shows sample events so you can preview the design.

## Connect your backend
Open `app.js` and change:

```js
const API_BASE = "http://localhost:5000/api";
```

to your backend API base URL.

The frontend expects these routes from the question paper:
- `POST /auth/register`
- `POST /auth/login`
- `POST /events`
- `GET /events`
- `GET /events/:id`
- `PUT /events/:id`
- `DELETE /events/:id`
- `POST /registrations`
- `GET /registrations/user/:userId`
- `GET /registrations/event/:eventId`
- `PUT /registrations/:id/status`

The optional feedback form uses `POST /feedback`.

## Expected API conventions
- JSON request and response bodies.
- Login/register should return a user object. Login should also return a token if your backend uses token authentication.
- If a token is returned, the frontend sends it as `Authorization: Bearer <token>`.
- Event objects should include `eventId` (or `_id`), `title`, `description`, `date`, `time`, `venue`, `eventType`, `regLimit`, and optionally `registeredCount`.
- Registration objects should include a status such as `Pending`, `Confirmed`, or `Rejected`. Include populated `event` and `user` objects where possible for the dashboard tables.

## Important integration notes
- The sample events are preview-only. Registration and event changes are saved only when the backend is connected.
- The sample API route list in the supplied question paper does not define exact JSON request/response shapes, token format, or feedback API route. Adjust the field names and paths in `app.js` to match your actual backend.
- Enable CORS on your backend for the frontend's origin.
- Never store plaintext passwords in local storage or return them from the API.
