/*
  EventHub frontend
  Connected to Node.js and Express backend.
*/

const API_BASE = "http://localhost:5000/api";

const DEMO_EVENTS = [
    {
        eventId: "demo1",
        title: "Future Tech Summit",
        description: "Explore emerging technologies, meet innovators and discover what's next.",
        date: "2026-12-08",
        time: "10:00",
        venue: "Main Auditorium",
        eventType: "Tech",
        regLimit: 180,
        registeredCount: 86
    },
    {
        eventId: "demo2",
        title: "Rhythm & Roots Cultural Fest",
        description: "A celebration of music, dance, art and cultures.",
        date: "2026-12-12",
        time: "16:30",
        venue: "Open Air Theatre",
        eventType: "Cultural",
        regLimit: 250,
        registeredCount: 194
    },
    {
        eventId: "demo3",
        title: "Design Thinking Workshop",
        description: "Turn everyday problems into creative ideas.",
        date: "2026-12-17",
        time: "11:00",
        venue: "Innovation Lab",
        eventType: "Workshop",
        regLimit: 60,
        registeredCount: 32
    }
];

let events = [...DEMO_EVENTS];
let registrations = [];
let user = JSON.parse(localStorage.getItem("eventhub_user") || "null");
let authMode = "login";
let demoMode = true;

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

const formData = form =>
    Object.fromEntries(new FormData(form).entries());

const dateLabel = value =>
    value
        ? new Date(value + "T00:00:00").toLocaleDateString("en-IN", {
            day: "numeric",
            month: "short",
            year: "numeric"
        })
        : "Date to be announced";

const safe = value =>
    String(value ?? "").replace(/[&<>"']/g, c => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    }[c]));

function toast(message) {
    const el = $("#toast");
    if (!el) return;

    el.textContent = message;
    el.classList.add("show");

    setTimeout(() => el.classList.remove("show"), 2800);
}

function token() {
    return localStorage.getItem("eventhub_token");
}

// API CONNECTION
async function api(path, options = {}) {
    const headers = {
        "Content-Type": "application/json",
        ...(options.headers || {})
    };

    if (token()) {
        headers.Authorization = `Bearer ${token()}`;
    }

    const response = await fetch(`${API_BASE}${path}`, {
        ...options,
        headers
    });

    const body = response.status === 204
        ? null
        : await response.json().catch(() => null);

    if (!response.ok) {
        throw new Error(
            body?.message || body?.error || `Request failed (${response.status})`
        );
    }

    return body;
}

// USER DETAILS
function setUser(next) {
    user = next;

    if (user) {
        localStorage.setItem("eventhub_user", JSON.stringify(user));
    } else {
        localStorage.removeItem("eventhub_user");
    }

    updateUserUI();
}

function updateUserUI() {
    $("#profile-name").textContent = user?.name || user?.email || "Guest";
    $("#profile-role").textContent = user?.role || "Not signed in";

    $("#avatar").textContent =
        (user?.name || user?.email || "G").charAt(0).toUpperCase();

    $("#auth-button").textContent = user ? "↪" : "↗";
    $("#auth-button").title = user ? "Sign out" : "Sign in";

    $("#role-pill").textContent =
        user ? `${user.role} view` : "Guest view";

    $$(".organizer-only").forEach(el => {
        el.hidden = user?.role !== "organizer";
    });

    $("#top-create").hidden = user?.role !== "organizer";
}

// PAGE NAVIGATION
function showPage(page) {
    const names = {
        home: "Discover events",
        "my-events": "My registrations",
        dashboard: "Organizer dashboard",
        manage: "Manage events"
    };

    if (
        ["dashboard", "manage"].includes(page) &&
        user?.role !== "organizer"
    ) {
        toast("Please sign in as an organizer.");
        showAuth();
        return;
    }

    $$(".page").forEach(el => el.hidden = true);

    $(`#${page}-page`).hidden = false;

    $$(".nav-link").forEach(el => {
        el.classList.toggle("active", el.dataset.page === page);
    });

    $("#page-heading").textContent = names[page] || "Discover events";

    if (page === "my-events") loadMyRegistrations();
    if (page === "dashboard") loadDashboard();
    if (page === "manage") renderManagedEvents();
}

function showAuth() {
    $$(".page").forEach(el => el.hidden = true);
    $("#auth-panel").hidden = false;
    $("#page-heading").textContent = "Welcome to EventHub";
}

function hideAuth() {
    $("#auth-panel").hidden = true;
    showPage("home");
}

// LOGIN AND REGISTER TABS
function setAuthMode(mode) {
    authMode = mode;

    $$(".tab").forEach(b => {
        b.classList.toggle("active", b.dataset.auth === mode);
    });

    $("#name-wrap").hidden = mode === "login";
    $("#role-wrap").hidden = mode === "login";

    $("#auth-submit").textContent =
        mode === "login" ? "Sign in" : "Create account";
}

// LOAD EVENTS
async function loadEvents() {
    try {
        const data = await api("/events");

        events = Array.isArray(data)
            ? data
            : (data?.events || []);

        demoMode = false;

    } catch (e) {
        demoMode = true;
        events = [...DEMO_EVENTS];

        console.info("Using sample events:", e.message);
    }

    renderEvents();
}

// DISPLAY EVENTS
function renderEvents() {
    const q = $("#search-input").value.trim().toLowerCase();
    const type = $("#type-filter").value;
    const date = $("#date-filter").value;

    const filtered = events.filter(e =>
        (!q || `${e.title} ${e.description || ""}`.toLowerCase().includes(q)) &&
        (!type || e.eventType === type) &&
        (!date || e.date === date)
    );

    $("#event-count").textContent =
        `${filtered.length} event${filtered.length === 1 ? "" : "s"} found`;

    $("#event-grid").innerHTML = filtered.length
        ? filtered.map(e => `
            <article class="event-card">
                <div class="event-banner ${safe((e.eventType || "").toLowerCase())}">
                    <span class="type-chip">${safe(e.eventType || "EVENT")}</span>
                    <span class="banner-symbol">${symbol(e.eventType)}</span>
                </div>

                <div class="event-body">
                    <div class="event-date">
                        ${dateLabel(e.date).toUpperCase()} · ${safe(e.time || "TIME TBA")}
                    </div>

                    <h3>${safe(e.title)}</h3>

                    <p>${safe(e.description || "Join this event.")}</p>

                    <div class="event-meta">
                        <span>⌖ ${safe(e.venue || "Venue TBA")}</span>
                        <span>♧ ${Number(e.registeredCount || 0)}/${Number(e.regLimit || 0)}</span>
                    </div>

                    <div class="event-actions">
                        <button class="primary-button"
                            onclick="registerEvent('${safe(e.eventId || e._id)}')">
                            Register now →
                        </button>
                    </div>
                </div>
            </article>
        `).join("")
        : '<div class="empty-state">No events match your search.</div>';
}

function symbol(type) {
    return ({
        Tech: "⌘",
        Cultural: "✺",
        Seminar: "◈",
        Workshop: "✎",
        Sports: "⚑"
    })[type] || "✦";
}

// EVENT REGISTRATION
async function registerEvent(id) {
    if (!user) {
        toast("Please sign in before registering.");
        showAuth();
        return;
    }

    if (user.role !== "participant") {
        toast("Only participants can register for events.");
        return;
    }

    if (demoMode) {
        toast("Events API is not connected yet.");
        return;
    }

    try {
        await api("/registrations", {
            method: "POST",
            body: JSON.stringify({ eventId: id })
        });

        toast("Registration submitted successfully!");
        loadEvents();

    } catch (e) {
        toast(e.message);
    }
}

// MY REGISTRATIONS
async function loadMyRegistrations() {
    if (!user) {
        $("#my-registrations").innerHTML =
            '<tr><td colspan="4">Please sign in.</td></tr>';
        return;
    }

    try {
        const data = await api(
            `/registrations/user/${encodeURIComponent(user.userId || user.id)}`
        );

        registrations = Array.isArray(data)
            ? data
            : (data?.registrations || []);

        $("#my-registrations").innerHTML = registrations.length
            ? registrations.map(r => {
                const e = r.event || r.eventDetails || {};

                return `
                    <tr>
                        <td>${safe(e.title || r.eventTitle || "Event")}</td>
                        <td>${dateLabel(e.date || r.date)} · ${safe(e.time || "")}</td>
                        <td>${safe(e.venue || "—")}</td>
                        <td>${safe(r.status || "Pending")}</td>
                    </tr>
                `;
            }).join("")
            : '<tr><td colspan="4">No registrations yet.</td></tr>';

    } catch (e) {
        $("#my-registrations").innerHTML =
            `<tr><td colspan="4">${safe(e.message)}</td></tr>`;
    }
}

// ORGANIZER DASHBOARD
async function loadDashboard() {
    const table = $("#organizer-registrations");

    try {
        await loadEvents();

        const data = await api("/registrations/organizer");

        registrations = Array.isArray(data)
            ? data
            : (data?.registrations || []);

        const currentUserId = String(user?.userId || user?.id || "");

        const ownEvents = events.filter(e => {
            const organizerId = e.organizer?._id || e.organizer;
            return String(organizerId || "") === currentUserId;
        });

        $("#stat-total").textContent = ownEvents.length;

        $("#stat-active").textContent = ownEvents.filter(e =>
            !e.date || new Date(e.date + "T00:00:00") >= new Date(new Date().toDateString())
        ).length;

        $("#stat-pending").textContent =
            registrations.filter(r => r.status === "Pending").length;

        table.innerHTML = registrations.length
            ? registrations.map(r => {
                const event = r.event || {};
                const participant = r.user || {};

                return `
                    <tr>
                        <td>${safe(event.title || "Event")}</td>
                        <td>${safe(participant.name || "Participant")}</td>
                        <td>${safe(participant.email || "—")}</td>
                        <td>${dateLabel(event.date)}</td>
                        <td>
                            ${safe(r.status || "Pending")}
                            <button type="button"
                                onclick="updateRegistration('${safe(r._id)}', 'Approved')">
                                Approve
                            </button>
                            <button type="button"
                                onclick="updateRegistration('${safe(r._id)}', 'Rejected')">
                                Reject
                            </button>
                        </td>
                    </tr>
                `;
            }).join("")
            : '<tr><td colspan="5">No registrations yet.</td></tr>';

    } catch (e) {
        $("#stat-pending").textContent = "0";
        table.innerHTML =
            `<tr><td colspan="5">${safe(e.message)}</td></tr>`;
    }
}

// UPDATE REGISTRATION STATUS
async function updateRegistration(id, status) {
    try {
        await api(`/registrations/${encodeURIComponent(id)}/status`, {
            method: "PUT",
            body: JSON.stringify({ status })
        });

        toast(`Registration ${status.toLowerCase()}.`);
        loadDashboard();

    } catch (e) {
        toast(e.message);
    }
}

// MANAGE EVENTS
function renderManagedEvents() {
    const own = events;

    $("#managed-events").innerHTML = own.length
        ? own.map(e => `
            <div class="managed-item">
                <div class="mini-art">${symbol(e.eventType)}</div>
                <div class="managed-copy">
                    <strong>${safe(e.title)}</strong>
                    <small>${dateLabel(e.date)} · ${safe(e.venue || "")}</small>
                </div>
            </div>
        `).join("")
        : '<div class="empty-state">No events created yet.</div>';
}

function editEvent(id) {
    const e = events.find(x =>
        String(x.eventId || x._id) === String(id)
    );

    if (!e) return;

    const f = $("#event-form");

    Object.entries({
        eventId: e.eventId || e._id,
        title: e.title,
        description: e.description,
        date: e.date,
        time: e.time,
        venue: e.venue,
        eventType: e.eventType,
        regLimit: e.regLimit
    }).forEach(([k, v]) => {
        if (f.elements[k]) f.elements[k].value = v ?? "";
    });

    $("#event-form-title").textContent = "Edit event";
    $("#cancel-edit").hidden = false;

    showPage("manage");
}

function resetEventForm() {
    $("#event-form").reset();
    $("#event-form").elements.eventId.value = "";
    $("#event-form-title").textContent = "Create an event";
    $("#cancel-edit").hidden = true;
}

async function deleteEvent(id) {
    if (!confirm("Delete this event?")) return;

    try {
        await api(`/events/${encodeURIComponent(id)}`, {
            method: "DELETE"
        });

        toast("Event deleted.");
        await loadEvents();
        renderManagedEvents();

    } catch (e) {
        toast(e.message);
    }
}

async function saveEvent(ev) {
    ev.preventDefault();

    if (user?.role !== "organizer") {
        toast("Sign in as an organizer first.");
        return;
    }

    const d = formData(ev.currentTarget);
    const id = d.eventId;

    delete d.eventId;
    d.regLimit = Number(d.regLimit);

    try {
        if (demoMode) {
            throw new Error("Events API is not connected yet.");
        }

        if (id) {
            await api(`/events/${encodeURIComponent(id)}`, {
                method: "PUT",
                body: JSON.stringify(d)
            });
        } else {
            await api("/events", {
                method: "POST",
                body: JSON.stringify(d)
            });
        }

        toast("Event saved successfully!");
        resetEventForm();

        await loadEvents();
        renderManagedEvents();

    } catch (e) {
        toast(e.message);
    }
}

// AUTHENTICATION - REGISTER AND LOGIN
async function submitAuth(ev) {
    ev.preventDefault();

    const d = formData(ev.currentTarget);

    try {
        const result = await api(
            authMode === "login" ? "/auth/login" : "/auth/register",
            {
                method: "POST",
                body: JSON.stringify(d)
            }
        );

        if (authMode === "register") {
            toast("Registration successful! Please sign in.");

            ev.currentTarget.reset();
            setAuthMode("login");

            return;
        }

        localStorage.setItem("eventhub_token", result.token);

        const account = result.user;

        setUser({
            userId: account.id,
            name: account.name,
            email: account.email,
            role: account.role
        });

        toast("Welcome to EventHub!");

        hideAuth();
        ev.currentTarget.reset();

        await loadEvents();

    } catch (error) {
        toast(error.message);
    }
}

// BUTTON EVENT LISTENERS
$("#auth-button").addEventListener("click", () => {
    if (user) {
        localStorage.removeItem("eventhub_token");
        localStorage.removeItem("eventhub_user");

        setUser(null);

        toast("Signed out.");
        showPage("home");

    } else {
        showAuth();
    }
});

$$("[data-page]").forEach(el => {
    el.addEventListener("click", () => {
        if (el.dataset.page) showPage(el.dataset.page);
    });
});

$$("[data-auth]").forEach(el => {
    el.addEventListener("click", () => {
        setAuthMode(el.dataset.auth);
    });
});

$("#auth-form").addEventListener("submit", submitAuth);

$("#event-form").addEventListener("submit", saveEvent);

$("#cancel-edit").addEventListener("click", resetEventForm);

["search-input", "type-filter", "date-filter"].forEach(id => {
    $("#" + id).addEventListener("input", renderEvents);
});

$("#clear-filters").addEventListener("click", () => {
    $("#search-input").value = "";
    $("#type-filter").value = "";
    $("#date-filter").value = "";

    renderEvents();
});

$("#explore-button").addEventListener("click", () => {
    $("#event-grid").scrollIntoView({ behavior: "smooth" });
});

$("#top-create").addEventListener("click", () => {
    showPage("manage");
});

$("#feedback-form").addEventListener("submit", async ev => {
    ev.preventDefault();

    const d = formData(ev.currentTarget);

    try {
        await api("/feedback", {
            method: "POST",
            body: JSON.stringify(d)
        });

        toast("Thank you for your feedback!");
        $("#feedback-dialog").close();

    } catch (e) {
        toast(e.message);
    }
});

// INITIALIZE WEBSITE
updateUserUI();
setAuthMode("login");
loadEvents();