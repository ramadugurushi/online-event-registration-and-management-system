const mongoose = require("mongoose");

const eventSchema = new mongoose.Schema({
    title: { type: String, required: true },
    description: { type: String, required: true },
    date: { type: String, required: true },
    time: { type: String },
    venue: { type: String, required: true },
    eventType: { type: String, required: true },
    regLimit: { type: Number, default: 100 },
    registeredCount: { type: Number, default: 0 },
    organizer: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: true
    }
}, { timestamps: true });

module.exports = mongoose.model("Event", eventSchema);