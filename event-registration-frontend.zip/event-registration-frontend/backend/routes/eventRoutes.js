const express = require("express");
const jwt = require("jsonwebtoken");
const Event = require("../models/Event");

const router = express.Router();

// Verify login
const verifyToken = (req, res, next) => {
    const token = req.headers.authorization?.split(" ")[1];

    if (!token) {
        return res.status(401).json({ message: "Please login first" });
    }

    try {
        req.user = jwt.verify(token, process.env.JWT_SECRET);
        next();
    } catch (error) {
        res.status(401).json({ message: "Invalid token" });
    }
};

// Get all events
router.get("/", async (req, res) => {
    try {
        const events = await Event.find().sort({ createdAt: -1 });
        res.json(events);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Create event
router.post("/", verifyToken, async (req, res) => {
    try {
        if (req.user.role !== "organizer") {
            return res.status(403).json({
                message: "Only organizers can create events"
            });
        }

        const { title, description, date, time, venue, eventType, regLimit } = req.body;

        if (!title || !description || !date || !venue || !eventType) {
            return res.status(400).json({
                message: "Please fill all required event details"
            });
        }

        const event = await Event.create({
            title,
            description,
            date,
            time,
            venue,
            eventType,
            regLimit: Number(regLimit) || 100,
            organizer: req.user.id
        });

        res.status(201).json({
            message: "Event created successfully!",
            event
        });

    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Update event
router.put("/:id", verifyToken, async (req, res) => {
    try {
        if (req.user.role !== "organizer") {
            return res.status(403).json({ message: "Organizer access required" });
        }

        const event = await Event.findOneAndUpdate(
            { _id: req.params.id, organizer: req.user.id },
            req.body,
            { new: true, runValidators: true }
        );

        if (!event) {
            return res.status(404).json({ message: "Event not found" });
        }

        res.json({ message: "Event updated successfully!", event });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Delete event
router.delete("/:id", verifyToken, async (req, res) => {
    try {
        if (req.user.role !== "organizer") {
            return res.status(403).json({ message: "Organizer access required" });
        }

        const event = await Event.findOneAndDelete({
            _id: req.params.id,
            organizer: req.user.id
        });

        if (!event) {
            return res.status(404).json({ message: "Event not found" });
        }

        res.json({ message: "Event deleted successfully!" });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;