const express = require("express");
const jwt = require("jsonwebtoken");
const Registration = require("../models/Registration");
const Event = require("../models/Event");

const router = express.Router();

// Verify login
const verifyToken = (req, res, next) => {
    const token = req.headers.authorization?.split(" ")[1];

    if (!token) {
        return res.status(401).json({ message: "Please login first" });
    }

    try {
        req.user = jwt.verify(token, process.env.JWT_SECRET);
        next();
    } catch (error) {
        res.status(401).json({ message: "Invalid token" });
    }
};

// Participant registers for an event
router.post("/", verifyToken, async (req, res) => {
    try {
        if (req.user.role !== "participant") {
            return res.status(403).json({
                message: "Only participants can register"
            });
        }

        const { eventId } = req.body;
        const event = await Event.findById(eventId);

        if (!event) {
            return res.status(404).json({ message: "Event not found" });
        }

        if (event.registeredCount >= event.regLimit) {
            return res.status(400).json({
                message: "Event registration is full"
            });
        }

        const registration = await Registration.create({
            user: req.user.id,
            event: eventId
        });

        event.registeredCount += 1;
        await event.save();

        res.status(201).json({
            message: "Registration successful!",
            registration
        });
    } catch (error) {
        if (error.code === 11000) {
            return res.status(400).json({
                message: "You already registered for this event"
            });
        }

        res.status(500).json({ message: error.message });
    }
});

// Participant views their registrations
router.get("/user/:userId", verifyToken, async (req, res) => {
    try {
        if (req.user.id !== req.params.userId) {
            return res.status(403).json({ message: "Access denied" });
        }

        const registrations = await Registration.find({
            user: req.params.userId
        }).populate("event");

        res.json(registrations);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Organizer views registrations for their events
router.get("/organizer", verifyToken, async (req, res) => {
    try {
        if (req.user.role !== "organizer") {
            return res.status(403).json({ message: "Organizer access required" });
        }

        const events = await Event.find({ organizer: req.user.id });
        const eventIds = events.map(event => event._id);

        const registrations = await Registration.find({
            event: { $in: eventIds }
        }).populate("user", "name email").populate("event");

        res.json(registrations);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Organizer updates registration status
router.put("/:id/status", verifyToken, async (req, res) => {
    try {
        if (req.user.role !== "organizer") {
            return res.status(403).json({ message: "Organizer access required" });
        }

        const { status } = req.body;

        if (!["Pending", "Approved", "Rejected"].includes(status)) {
            return res.status(400).json({ message: "Invalid status" });
        }

        const registration = await Registration.findById(req.params.id)
            .populate("event");

        if (!registration) {
            return res.status(404).json({ message: "Registration not found" });
        }

        if (String(registration.event.organizer) !== req.user.id) {
            return res.status(403).json({ message: "Access denied" });
        }

        registration.status = status;
        await registration.save();

        res.json({
            message: "Registration status updated",
            registration
        });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;